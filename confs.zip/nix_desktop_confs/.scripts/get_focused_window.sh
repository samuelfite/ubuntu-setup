#!/bin/bash

res=$(i3-msg -t get_tree | jq '.nodes[].nodes[].nodes[].nodes[] | select(.focused)')
echo "${res}"
