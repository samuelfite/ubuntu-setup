#!/bin/bash 
#unlock partition
#cryptsetup luksOpen /dev/sde sde-enc

#import the pool
/sbin/zpool import -c /etc/zfs/zpool.cache -aN

zfs mount -a
