#!/bin/sh
# Set wallpaper with command below
 feh --bg-scale /home/sam/Pictures/bg.png
# To restore the wallpaper from last session
#~/.fehbg &

