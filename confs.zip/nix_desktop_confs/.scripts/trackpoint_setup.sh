#!/bin/bash
xinput set-button-map 'TPPS/2 IBM TrackPoint' 1 0 3 4 5 6 7\n
echo "we good"
exit 0

