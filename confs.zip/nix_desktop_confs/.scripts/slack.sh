#!/bin/bash
i3-msg 'workspace 1; exec xterm -e slack &'
exit
