#!/bin/bash

enabled=0
count=1
while true; do
    xset s on

    # every 30seconds, check to start autolock timer
    ((count+=1))
    rem=$((count%30))
    if [[ $rem -eq 0 ]]; then
        count=1
        no_lock=$(python3 /home/sam/.scripts/focused.py)
        if [[ ${no_lock} == "1" ]]; then
            xautolock -disable
            enabled=0
        else
            # don't double enable, resets timer for autolock
            if [[ $enabled -eq 0 ]]; then
                xautolock -enable
                enabled=1
            fi
        fi
    fi

    c=$(ps -ef | grep "compton --" | grep -v "grep" |head -n 1)
    i=$(ps -ef | grep "i3lock-fancy" | grep -v "grep" | head -n 1)
    
    compton=$(awk '{print $0}' <<< "${c}")
    i3lock=$(awk '{print $0}' <<< "${i}")

    comptonID=$(awk '{print $2}' <<< "${compton}" )
    comptonName=$(awk '{print $8}' <<< "${compton}" )

    i3ID=$(awk '{print $2}' <<< "${i3lock}" )
    i3Name=$(awk '{print $8}' <<< "${i3lock}" )

    i3lockRunning=0
    comptonRunning=0
    if [[ ${#i3Name} -gt 6 ]] && [[ ${i3Name} != "xautolock" ]]; then
        i3lockRunning=1
    fi
    if [[ ${#comptonName} -gt 6 ]]; then
        comptonRunning=1
    fi

    if [[ ${i3lockRunning} -eq 1 ]]; then
        if [[ ${comptonRunning} -eq 1 ]]; then
            echo "KILLING COMPTONPID: ${comptonID}"
            kill -9 "${comptonID}"
        fi
    else
        if [[ $comptonRunning -eq 0 ]]; then
           compton --config ~/.config/compton/compton.conf &
           echo "STARTING COMPTON PID: $!"
       fi
    fi

    sleep 1
done
