#/usr/bin/env python3

import i3ipc
from pprint import pprint

i3 = i3ipc.Connection()
focused = i3.get_tree().find_focused()
name=str(focused.window_title).lower()
if 'vlc' in name or 'youtube' in name:
    print( "1" )
else:
    print( "0" )


