# !/bin/sh
xrdb -load ~/.Xresources
xrdb -merge ~/.Xresources
