#!/bin/sh
xrandr --output eDP1 --mode 1920x1080
