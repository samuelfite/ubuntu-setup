#!/bin/bash
output="$(xrandr | grep -G " connected" | awk '{print $1}')"
output=( $output )
echo "${output[2]}"
echo "${output[0]}"
echo "${output[1]}"
