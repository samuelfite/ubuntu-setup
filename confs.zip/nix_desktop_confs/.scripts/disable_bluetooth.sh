# !/bin/bash
rfkill block bluetooth
