#!/bin/bash
xterm -hold -e ~/builds/Postman/Postman &
