#!/bin/sh
# Set wallpaper with command below
 feh --bg-scale /home/sam/Pictures/bg_vert.png /home/sam/Pictures/bg.png /home/sam/Pictures/bg.png
# To restore the wallpaper from last session
#~/.fehbg &

