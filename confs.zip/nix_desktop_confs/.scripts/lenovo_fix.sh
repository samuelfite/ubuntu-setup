#!/bin/bash
sudo /home/sam/builds/throttled/lenovo_fix.py --debug &
