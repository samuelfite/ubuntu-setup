#!/bin/bash
xautolock -notify 30 -notifier "notify-send -u critical 'LOCKING SCREEN'" -time 5 -locker /usr/bin/i3lock-fancy
