#!/bin/sh
xinput disable 'SynPS/2 Synaptics TouchPad'
