import sys, os
import subprocess

MONITORS = list()

args = sys.argv

#get monitors
out = subprocess.check_output(['/home/sam/.scripts/get_monitors.sh']).decode("utf-8")
out = out.strip().split('\n')
for i in out:
    MONITORS.append(i)

original_contents = None
with open( args[1], "r" ) as fh:
    original_contents = fh.readlines()

for i in range(0,len(MONITORS)):
    monitor_name = "MONITOR" + str(i)
    monitor = MONITORS[i]
    new_line = "export " + monitor_name + "=\"" + monitor + "\"\n"

    found = 0
    for x in range(0,len(original_contents)):
        line = original_contents[x]
        if monitor_name in line:
            found = 1
            original_contents[x] = new_line

    if not found:
        original_contents.append(new_line)

print( original_contents )
with open( args[1], "w" ) as fh:
    fh.writelines(original_contents)



    
