emoticons=(
'¯\_(ツ)_/¯: Shruggie [emoticon]'
'ಠ_ಠ: Look of Disaproval [emoticon]'
'(V)g(;,,;) (V): Why not Zoidberg? [emoticon]'
'ʕ⁰●⁰ʔ: Bear [emoticon]'
'(° ͜ʖ ͡°): Lenny [emoticon]'
'(╯°□°）╯︵┻━┻:Table flip [emoticon]'
'(•___•): [emoticon]'
)
